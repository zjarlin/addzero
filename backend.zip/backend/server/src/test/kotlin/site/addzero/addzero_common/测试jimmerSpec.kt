package site.addzero.addzero_common

import org.junit.jupiter.api.Test

class 测试jimmerSpec(
) {

    @Test
    fun test(): Unit {

        println("hello")
    }


}


