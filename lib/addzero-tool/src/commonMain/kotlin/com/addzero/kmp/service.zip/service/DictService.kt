//package com.addzero.kmp.service
//
//import com.addzero.kmp.jdbc.meta.public.table.ISysDict
//import com.addzero.kmp.jdbc.meta.public.table.ISysDictItem
//import com.lt.lazy_people_http.annotations.LazyPeopleHttpService
//import org.koin.core.annotation.Single
//
//fun main() {
//    val length = "1178295274528845826".length
//    println()
//}
///**
// * 字典服务接口
// */
//@LazyPeopleHttpService
//interface DictService {
//    /**
//     * 获取字典树结构
//     */
//    suspend fun getDictTree(): List<ISysDict>
//
//    /**
//     * 根据ID获取字典信息
//     */
//    suspend fun getDictById(id: Long): DictDTO
//
//    /**
//     * 创建字典
//     */
//    suspend fun createDict(dict: DictDTO): DictDTO
//
//    /**
//     * 更新字典
//     */
//    suspend fun updateDict(dict: DictDTO): DictDTO
//
//    /**
//     * 删除字典
//     */
//    suspend fun deleteDict(id: Long): Boolean
//
//    /**
//     * 获取字典详情(包含子项)
//     */
//    suspend fun getDictDetail(id: Long): DictDetailDTO
//
//    /**
//     * 创建字典项
//     */
//    suspend fun createDictItem(dictItem: DictItemDTO): DictItemDTO
//
//    /**
//     * 更新字典项
//     */
//    suspend fun updateDictItem(dictItem: DictItemDTO): DictItemDTO
//
//    /**
//     * 删除字典项
//     */
//    suspend fun deleteDictItem(id: Long): Boolean
//
//    /**
//     * 根据字典编码获取字典项列表
//     */
//    suspend fun getDictItemsByCode(dictCode: String): List<DictItemDTO>
//}
//
//
///**
// * 字典详情DTO
// */
//data class DictDetailDTO(
//    val dict: ISysDict,
//    val items: List<ISysDictItem>
//)
//
