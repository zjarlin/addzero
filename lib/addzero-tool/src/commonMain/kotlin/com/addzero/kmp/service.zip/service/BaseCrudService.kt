//package com.addzero.kmp.service
//
//import com.addzero.kmp.util.data_structure.coll.Pageable
//import de.jensklingenberg.ktorfit.http.GET
//
///**
// * 用户服务接口
// */
//
//interface BaseCrudService<T> {
//
////    @GET("sysUser/getCurrentUser")
//    suspend fun page(): Pageable<T>
//
//    suspend fun list(): List<T>
//
//    suspend fun save(t: T): Boolean
//
//    suspend fun update(t: T): Boolean
//
//    /**
//     * 用户登出
//     */
//    suspend fun delete(id: Any): Boolean
//}
//
