//package com.addzero.kmp.service
//
//import com.addzero.kmp.core.network.apiClient
//import com.addzero.kmp.entity.sys.menu.SysMenuVO
//import com.addzero.kmp.ui.infra.model.menu.MenuApiService
//import io.ktor.client.*
//import io.ktor.client.call.*
//import io.ktor.client.request.*
//import io.ktor.http.ContentType
//import io.ktor.http.contentType
//
//
//interface SysMenuService :MenuApiService {
//
//    suspend fun getSysMenu(allRoutes: Any): Map<String, SysMenuVO>
//
//    companion object {
//        val instance = SysMenuServiceImpl(apiClient)
//    }
//}
//
//class SysMenuServiceImpl(private val client: HttpClient) : SysMenuService {
////    override suspend fun getSysMenu(allRoutes: String): Map<String, SysMenuVO> = client.get("/api/sys/menu/getSysMenu").body()
//
//
//    override suspend fun getSysMenu(params: Any): Map<String, SysMenuVO> {
//        val body = client.post("/api/sys/menu/getSysMenu") {
//            contentType(ContentType.Application.Json)
//            setBody(params)
//        }.body<Map<String, SysMenuVO>>()
//        return body
//    }
//
//    override suspend fun getMenus(): Map<String, SysMenuVO> {
//        val body = client.post("/api/sys/menu/getSysMenu") {
//            contentType(ContentType.Application.Json)
//            setBody(body = mapOf("allRoutes" to true))
//        }.body<Map<String, SysMenuVO>>()
//        return body
//    }
//
//    override suspend fun saveMenus(menus: Map<String, SysMenuVO>): Boolean {
//       return true
//    }
//
//    override suspend fun addMenu(menu: SysMenuVO): Boolean {
//        return true
//    }
//
//    override suspend fun updateMenu(menu: SysMenuVO): Boolean {
//        return true
//    }
//
//    override suspend fun deleteMenu(path: String): Boolean {
//        return true
//    }
//}