package com.addzero.kmp.service

import com.addzero.kmp.jdbc.meta.public.table.ISysUser
import de.jensklingenberg.ktorfit.http.GET
import de.jensklingenberg.ktorfit.http.POST
import de.jensklingenberg.ktorfit.http.Query

/**
 * 用户服务接口
 */

interface UserService {

    /**
     * 获取当前用户信息
     */
    @GET("sysUser/getCurrentUser")
   suspend fun getCurrentUser(): ISysUser

    /**
     * 更新用户密码
     */
    @POST("sysUser/updatePassword")
    suspend fun updatePassword(@Query newPassword: String): Boolean

    /**
     * 用户登出
     */
    @POST("sysUser/logout")
    suspend fun logout(): Boolean
}

