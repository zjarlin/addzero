package com.addzero.kmp.service

import com.addzero.kmp.jdbc.meta.public.table.ISysArea
import com.addzero.kmp.util.data_structure.coll.Pageable
import de.jensklingenberg.ktorfit.http.Body
import de.jensklingenberg.ktorfit.http.GET
import de.jensklingenberg.ktorfit.http.POST
import de.jensklingenberg.ktorfit.http.Query

interface SysAreaService {
    @GET("sysArea/page")
    suspend fun page(): Pageable<ISysArea>

//    @GET("sysArea/list")
//    suspend fun list(): List<@Serializable  ISysArea>


    @GET("sysArea/list")
    suspend fun list():   kotlin.collections.List<ISysArea>


    @POST("sysArea/save")
    suspend fun save(@Body t: ISysArea): Boolean

    @POST("sysArea/update")
    suspend fun update(@Body t: ISysArea): Boolean

    @POST("sysArea/delete")
    suspend fun delete(@Query("id") id: String): Boolean

}
