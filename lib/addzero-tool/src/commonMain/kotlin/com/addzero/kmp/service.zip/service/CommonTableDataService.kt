package com.addzero.kmp.service

import com.addzero.kmp.entity.low_table.ExportParam
import com.addzero.kmp.entity.low_table.StateSearchForm
import com.addzero.kmp.entity.low_table.StateSort
import com.addzero.kmp.util.data_structure.coll.SpecPageResult
import de.jensklingenberg.ktorfit.http.Body
import de.jensklingenberg.ktorfit.http.GET
import kotlinx.serialization.Contextual
import kotlinx.serialization.Serializable

//@Serializable
data class CommonTableDaTaInputDTO(
    val tableName: String,
    //关键词
    val keyword: String,
    //排序条件
//       @Contextual
    val stateSorts: MutableSet<StateSort> = mutableSetOf(),
    //查询条件
//       @Contextual
    val stateSearchForms: MutableSet<StateSearchForm> = mutableSetOf<StateSearchForm>(),
)

/**
 * 低代码服务接口
 */

interface CommonTableDataService {

    /**
     * 获取当前用户信息
     */
    @GET("/common/getTable")
    suspend fun getTableData(@Body commonTableDaTaInputDTO:
                                  CommonTableDaTaInputDTO):
            SpecPageResult<Map<String,Any?>>


    @GET("/common/exportTable")
    suspend fun export(@Body exportParam: ExportParam): Boolean


}

