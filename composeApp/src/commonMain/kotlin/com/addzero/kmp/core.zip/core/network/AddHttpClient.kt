package com.addzero.kmp.core.network// 在 commonMain 中定义共享代码
//import com.lt.lazy_people_http.config.LazyPeopleHttpConfig
import de.jensklingenberg.ktorfit.Ktorfit
import io.ktor.client.*
import io.ktor.client.plugins.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.plugins.logging.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json

// 创建一个通用的 HTTP 客户端工具类
expect val apiClient: HttpClient

val json = Json {
    ignoreUnknownKeys = true
    isLenient = true
    prettyPrint = true
    useAlternativeNames = false
    // 尝试启用多态序列化支持
    classDiscriminator = "jdbcType"
    // 允许将值强制转换为目标类型
    coerceInputValues = true
}

private const val BASE_URL = "http://localhost:12344"

object AddHttpClient {





    //    val hfconfig = LazyPeopleHttpConfig(apiClient)
    val ktorfit = Ktorfit.Builder().httpClient(apiClient)
//   .converterFactories(MyOwnResponseConverterFactory())
        .build()

    // Mock的token获取方式
    private var mytoken: String? = "dasdasdasd"

    // 设置mock token
    fun setToken(token: String?) {
        mytoken = token
    }

    // 获取当前token
    fun getCurrentToken(): String? = mytoken

    fun configClient(): HttpClientConfig<*>.() -> Unit = {
        //请求头配置
        configHeaders()
        //基础url配置
        configUrl()
        //日志插件
        configLog()
        //json解析插件
        configJson()
        //响应
        configBaseRes()
    }

    // 使用 expect/actual 模式，让每个平台提供自己的 HttpClient 实例

    fun HttpClientConfig<*>.configUrl() {
        defaultRequest {
//            url("https://api.apiopen.top")
            url(BASE_URL)
        }
    }

    fun HttpClientConfig<*>.configHeaders() {
        defaultRequest {
            // 添加基础请求头
            headers {
                append(HttpHeaders.Accept, "application/json")
                append(HttpHeaders.ContentType, "application/json")
            }

            // 添加token
            mytoken?.let { token ->
                headers {
                    append(HttpHeaders.Authorization, "Bearer $token")
                }
            }
        }
    }

    fun HttpClientConfig<*>.configBaseRes() {
        install(BaseResponsePlugin) {
            keysForStatus = listOf("code")
            successCode = "200"
            keysForData = listOf("data")
        }
    }

    fun HttpClientConfig<*>.configLog() {
        install(Logging) {
            logger = Logger.DEFAULT
            level = LogLevel.ALL
        }
    }

    fun HttpClientConfig<*>.configJson() {
        install(ContentNegotiation) {
            json(json)
        }
    }

    // 示例 GET 请求方法
    internal suspend inline fun <reified T> get(url: String): T {
        val response = apiClient.get(url)
        val string = response.bodyAsText()
        return try {
            // 首先尝试标准方式解析
            json.decodeFromString(string)
        } catch (e: Exception) {
            // 如果失败，使用通用转换工具
            SerializationUtils.convertResponse(string)
        }
    }

    // 示例 POST 请求方法
    internal suspend inline fun <reified T, reified R> post(url: String, body: T): R {
        val response = apiClient.post(url) {
            setBody(body)
        }
        val string = response.bodyAsText()
        return try {
            // 首先尝试标准方式解析
            json.decodeFromString(string)
        } catch (e: Exception) {
            // 如果失败，使用通用转换工具
            SerializationUtils.convertResponse(string)
        }
    }

}

