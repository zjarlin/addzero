//package com.addzero.kmp.core.network
//
//import com.addzero.kmp.entity.Res
//import kotlinx.serialization.KSerializer
//import kotlinx.serialization.builtins.serializer
//import kotlinx.serialization.descriptors.buildClassSerialDescriptor
//import kotlinx.serialization.encoding.Decoder
//import kotlinx.serialization.encoding.Encoder
//import kotlinx.serialization.json.JsonDecoder
//import kotlinx.serialization.json.JsonEncoder
//import kotlinx.serialization.json.buildJsonObject
//import kotlinx.serialization.json.int
//import kotlinx.serialization.json.jsonObject
//import kotlinx.serialization.json.jsonPrimitive
//import kotlinx.serialization.json.JsonPrimitive
//
//class ResSerializer<T>(private val dataSerializer: KSerializer<T>) : KSerializer<Res<T>> {
//    override val descriptor = buildClassSerialDescriptor("com.addzero.kmp.entity.Res") {
//        element("code", Int.serializer().descriptor)
//        element("message", String.serializer().descriptor)
//        element("data", dataSerializer.descriptor, isOptional = true)
//    }
//
//    override fun deserialize(decoder: Decoder): Res<T> {
//        val input = decoder as? JsonDecoder ?: error("Only JSON format is supported")
//        val jsonObj = input.decodeJsonElement().jsonObject
//
//        val code = jsonObj["code"]?.jsonPrimitive?.int ?: 200
//        val message = jsonObj["message"]?.jsonPrimitive?.content ?: "请求成功"
//        val data = jsonObj["data"]?.let { input.json.decodeFromJsonElement(dataSerializer, it) }
//
//        return Res(code, message, data)
//    }
//
//    override fun serialize(encoder: Encoder, columnValue: Res<T>) {
//        val output = encoder as? JsonEncoder ?: error("Only JSON format is supported")
//        val jsonObj = buildJsonObject {
//            put("code", JsonPrimitive(columnValue.code))
//            put("message", JsonPrimitive(columnValue.message))
//            columnValue.data?.let { put("data", output.json.encodeToJsonElement(dataSerializer, it)) }
//        }
//        output.encodeJsonElement(jsonObj)
//    }
//}
