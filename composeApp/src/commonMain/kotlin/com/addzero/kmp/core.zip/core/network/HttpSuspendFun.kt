//package com.lt.dygzs.common.utils.extend
//
//import com.lt.data_structure.util._currentTimeMillis
//import com.lt.data_structure.values.Values3
//import com.lt.data_structure.values.Values4
//import com.lt.data_structure.values.Values5
//import com.lt.dygzs.common.base.active.BaseActive
//import com.lt.dygzs.common.config.sub
//import com.lt.dygzs.common.http.*
//import com.lt.dygzs.common.manager.AppManager
//import com.lt.dygzs.common.model.NetBean
//import com.lt.dygzs.common.utils.*
//import com.lt.dygzs.stdutil.EmptyListener
//import com.lt.dygzs.stdutil.cancelAndThrow
//import com.lt.dygzs.stdutil.checkCoroutineStateOrThrow
//import com.lt.dygzs.common.utils.extend.format
//import io.ktor.client.network.sockets.*
//import io.ktor.client.plugins.*
//import io.ktor.utils.io.errors.*
//import kotlinx.coroutines.async
//import kotlinx.coroutines.coroutineScope
//import kotlinx.coroutines.delay
//import kotlinx.coroutines.flow.Flow
//import kotlinx.coroutines.flow.flow
//import kotlin.coroutines.cancellation.CancellationException
//
///**
// * creator: lt  2020/9/24  lt.dygzs@qq.com
// * effect : 网络请求相关挂起函数
// * warning:
// */
//
///**
// * 检查协程网络请求的返回值和当前状态是否符合要求
// * 如果不符合要求,会调用失败的回调,并取消当前协程
// */
//suspend fun <T> C<T>.get(errorListener: ((code: Int, msg: String, e: Throwable?) -> Boolean)? = null): T & Any =
//    getOrNull(errorListener) ?: cancelAndThrow()
//
///**
// * 检查协程网络请求的返回值和当前状态是否符合要求
// * 如果不符合要求,会调用失败的回调,并返回null,不会取消当前协程
// * [errorListener]code:服务端返回的code,msg:服务端返回的消息,e:因为错误产生的异常,返回值:是否拦截,如果是true就不使用默认失败策略(即弹toast)
// */
//suspend fun <T> C<T>.getOrNull(errorListener: ((code: Int, msg: String, e: Throwable?) -> Boolean)? = null): T? {
//    val netBean = getNetBeanOrNull(errorListener) ?: return null
//    if (!sub.isSuccess(netBean)) {
//        HandlerPool.tryPost {
//            if (errorListener?.invoke(netBean.code, netBean.msg ?: "", null) != true)
//                netBean.msg.showToast()
//        }
//        return null
//    }
//    return netBean.data
//}
//
///**
// * 通过协程请求网络,并将数据通过flow发送出去
// * ps:记得调用collect
// */
//fun <T> C<T>.createFlow(): Flow<LoadingState<out T>> = flow {
//    emit(Loading)
//    var message: String? = null
//    var throwable: Throwable? = null
//    val result = getOrNull { code, msg, e ->
//        message = msg
//        throwable = e
//        true
//    }
//    if (result != null)
//        emit(LoadingSuccess(result))
//    else
//        emit(LoadingFail(message, throwable))
//}
//
////通过协程(flow)请求网络,并将数据通过回调发送出去(省去了collect步骤,不容易忘)
//suspend fun <T> C<T>.getWithFlow(callback: (LoadingState<out T>) -> Unit) {
//    createFlow().collect(callback)
//}
//
//context(BaseActive)
//fun <T> C<T>.getWithFlow(callback: (LoadingState<out T>) -> Unit) {
//    main {
//        createFlow().collect(callback)
//    }
//}
//
////获取协程数据,并自动显示和隐藏弹窗
//suspend fun <T> C<T>.getWithDialog(errorListener: ((code: Int, msg: String, e: Throwable?) -> Boolean)? = null): T & Any =
//    getOrNullWithDialog(errorListener) ?: cancelAndThrow()
//
////获取协程数据,并自动显示和隐藏弹窗
//suspend fun <T> C<T>.getOrNullWithDialog(errorListener: ((code: Int, msg: String, e: Throwable?) -> Boolean)? = null): T? =
//    withDialog { getOrNull(errorListener) }
//
////获取协程数据,并且失败时不会弹出toast
//suspend fun <T> C<T>.getNotToast(): T & Any = get { _, _, _ -> true }
//
////进获取NetBean<T>,并且是成功的
//suspend fun <T> C<T>.getNetBeanWithSuccess(errorListener: ((code: Int, msg: String, e: Throwable?) -> Boolean)? = null): NetBean<T> {
//    val netBean = getNetBeanOrNull(errorListener) ?: cancelAndThrow()
//    if (netBean.data != null && sub.isSuccess(netBean))
//        return netBean as NetBean<T>
//    HandlerPool.tryPost {
//        if (errorListener?.invoke(netBean.code, netBean.msg ?: "", null) != true)
//            netBean.msg.showToast()
//    }
//    cancelAndThrow()
//}
//
///**
// * 仅获取NetBean<T>,不做判断
// * code: -1:没进行请求,-2:请求了但异常,200:请求成功,其他:服务器返回的错误,
// */
//suspend fun <T> C<T>.getNetBeanOrNull(errorListener: ((code: Int, msg: String, e: Throwable?) -> Boolean)? = null): NetBean<T?>? {
//    if (!NetUtil.isNetworkAvailable()) {
//        val msg = sub.ss.netnotenble
//        HandlerPool.tryPost {
//            if (errorListener?.invoke(-1, msg, null) != true)
//                msg.showToast()
//        }
//        return null
//    }
//    val startTime = _currentTimeMillis()//开始请求时间
//    var callStatus = "失败"//是否请求成功
//    var url = ""
//    this@getNetBeanOrNull.config {
//        url = this.url.toString()
//    }
//    try {
//        val netBean = this@getNetBeanOrNull.await()
//        callStatus = "成功"
//        //优化页面切换时卡顿,等待页面切换动画完成后再返回数据和加载控件
//        AppManager.currentActivity()?.awaitSwitchingAnimation()
//        checkCoroutineStateOrThrow()
//        return netBean as NetBean<T?>
//    } catch (e: Throwable) {
//        // TODO 处理一下异常
//        //如果是被取消了
//        if (
//            e is CancellationException
//            || (e is IOException && e.message?.lowercase() == "canceled")
//        ) {
//            callStatus = "取消"
//            return null
//        }
//        e.e(isUpload = if (e is ClientRequestException && e.response.status.columnValue == 404) false else true)
//        checkCoroutineStateOrThrow()
//        val msg = if (e is SocketTimeoutException) {
//            sub.ss.service_time_out
//        } else {
//            if (sub.config.IS_DEBUG)
//                sub.ss.service_busy.format(e.message)
//            else
//                sub.ss.respose_error
//        }
//        HandlerPool.tryPost {
//            if (errorListener?.invoke(-2, msg, e) != true)
//                msg.showToast()
//        }
//        return null
//    } finally {
//        "$url 接口请求$callStatus,耗时:${_currentTimeMillis() - startTime}".w("lllttt_ktor")
//    }
//}
//
///**
// * 同时等待多个call并拿到他们的结果集
// */
//suspend fun <T1 : Any, T2 : Any> awaitCalls(
//    call1: C<T1>,
//    call2: C<T2>,
//    errorListener: ((code: Int, msg: String, e: Throwable?) -> Boolean)? = null
//): Pair<T1, T2> = coroutineScope {
//    val async1 = async(coroutineContext) { call1.get(errorListener) }
//    val t2 = call2.get(errorListener)
//    async1.await() to t2
//}
//
//suspend fun <T1 : Any, T2 : Any, T3 : Any> awaitCalls(
//    call1: C<T1>,
//    call2: C<T2>,
//    call3: C<T3>,
//    errorListener: ((code: Int, msg: String, e: Throwable?) -> Boolean)? = null
//): Values3<T1, T2, T3> = coroutineScope {
//    val async1 = async(coroutineContext) { call1.get(errorListener) }
//    val async2 = async(coroutineContext) { call2.get(errorListener) }
//    val t3 = call3.get(errorListener)
//    Values3(async1.await(), async2.await(), t3)
//}
//
//suspend fun <T1 : Any, T2 : Any, T3 : Any, T4 : Any> awaitCalls(
//    call1: C<T1>,
//    call2: C<T2>,
//    call3: C<T3>,
//    call4: C<T4>,
//    errorListener: ((code: Int, msg: String, e: Throwable?) -> Boolean)? = null
//): Values4<T1, T2, T3, T4> = coroutineScope {
//    val async1 = async(coroutineContext) { call1.get(errorListener) }
//    val async2 = async(coroutineContext) { call2.get(errorListener) }
//    val async3 = async(coroutineContext) { call3.get(errorListener) }
//    val t4 = call4.get(errorListener)
//    Values4(async1.await(), async2.await(), async3.await(), t4)
//}
//
//suspend fun <T1 : Any, T2 : Any, T3 : Any, T4 : Any, T5 : Any> awaitCalls(
//    call1: C<T1>,
//    call2: C<T2>,
//    call3: C<T3>,
//    call4: C<T4>,
//    call5: C<T5>,
//    errorListener: ((code: Int, msg: String, e: Throwable?) -> Boolean)? = null
//): Values5<T1, T2, T3, T4, T5> = coroutineScope {
//    val async1 = async(coroutineContext) { call1.get(errorListener) }
//    val async2 = async(coroutineContext) { call2.get(errorListener) }
//    val async3 = async(coroutineContext) { call3.get(errorListener) }
//    val async4 = async(coroutineContext) { call4.get(errorListener) }
//    val t5 = call5.get(errorListener)
//    Values5(async1.await(), async2.await(), async3.await(), async4.await(), t5)
//}
//
///**
// * 仅发送请求,不关心结果和过程,只要过程不出异常
// */
//fun <T : Any> C<T>.send(retry: Int = 3) {
//    if (retry <= 0)
//        return
//    app.mainScope.launchCPU {
//        try {
//            await()
//        } catch (e: Exception) {
//            if (e is CancellationException)
//                throw e
//            send(retry - 1)
//        }
//    }
//}
//
///**
// * 仅发送请求,且一直发送直到服务端返回正确的结果
// */
//fun <T : Any> C<T>.sendToSuccess(retry: Int = 3, onComplete: EmptyListener? = null) {
//    app.mainScope.launchCPU {
//        var call = this@sendToSuccess
//        for (i in 0..retry) {
//            if (call.getOrNull() != null) break
//            delay(100)
//        }
//        onComplete?.invoke()
//    }
//}
//
///**
// * 下载文件,如果下载大文件(大于10M)则不要使用readBytes
// * ps:[targetFilePath]对应的file必须先创建
// */
//suspend fun String.downloadFile(targetFilePath: String, errorListener: EmptyListener? = null) {
//    withIO {
//        try {
//            val byteArray = sub.hf.downloadFile(this@downloadFile)
//            FileUtil.writeByteArrayToFilePath(targetFilePath, byteArray)
//        } catch (e: Exception) {
//            e.e()
//            errorListener?.invoke()
//        }
//    }
//}
//
///**
// * 上传照片
// * [isCache]是否是不重要的图片,true会存到服务器的cache文件夹中随时可以被删除
// */
//expect suspend fun uploadPhoto(filePath: String, isCache: Boolean = false): Int
//
///**
// * 上传视频
// */
//expect suspend fun uploadVideo(filePath: String): Int
//
///**
// * 只上传照片,不压缩
// */
//suspend fun uploadPhotoJustGetId(filePath: String, isCache: Boolean = false): Int = withIO {
//    sub.hf.uploadPhoto(filePath, isCache).getDataOrThrow()
//}
//
//suspend fun <T> NetBean<T>.getDataOrThrow(): T {
//    if (!sub.isSuccess(this) || data == null)
//        cancelAndThrow()
//    return data!!
//}
