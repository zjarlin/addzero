package com.addzero.kmp.core.network

import com.addzero.kmp.entity.Res
import de.jensklingenberg.ktorfit.Ktorfit
import de.jensklingenberg.ktorfit.converter.Converter
import de.jensklingenberg.ktorfit.converter.KtorfitResult
import de.jensklingenberg.ktorfit.converter.TypeData
import io.ktor.client.call.body
import io.ktor.client.statement.HttpResponse

class MyOwnResponseConverterFactory : Converter.Factory{

    override fun suspendResponseConverter(
        typeData: TypeData,
        ktorfit: Ktorfit
    ): Converter.SuspendResponseConverter<HttpResponse, *>? {
        if(typeData.typeInfo.type == Res::class) {

            return object : Converter.SuspendResponseConverter<HttpResponse, Any> {
                override suspend fun convert(result: KtorfitResult): Any {
                    return when (result) {
                        is KtorfitResult.Failure -> {
                            val throwable = result.throwable
                            val message = throwable.message
                            Res.fail(message.toString())
                        }

                        is KtorfitResult.Success -> {
                            Res.success(result.response.body(typeData.typeArgs.first().typeInfo))
                        }
                    }
                }
            }
        }
        return null
    }
}