package com.addzero.kmp.core.network

import com.addzero.kmp.entity.Res
import kotlinx.serialization.json.*

/**
 * 序列化工具类，提供通用转换方法
 */
object SerializationUtils {

    /**
     * 将服务器返回的JSON转换为实体对象
     * 处理KSP生成的实体可能没有序列化器的情况
     */
    internal inline fun <reified T> convertResponse(jsonString: String): T {
        try {
            // 尝试直接使用标准方式解析
            return json.decodeFromString(jsonString)
        } catch (e: Exception) {
            // 如果标准方式失败，使用JsonElement中转
            val jsonElement = json.parseToJsonElement(jsonString)
            return convertJsonElement(jsonElement)
        }
    }
    
    /**
     * 将Res响应转换为实体
     */
    inline fun <reified T> convertResponseToRes(jsonString: String): Res<T> {
        val jsonObject = json.parseToJsonElement(jsonString).jsonObject
        
        val code = jsonObject["code"]?.jsonPrimitive?.int ?: 200
        val message = jsonObject["message"]?.jsonPrimitive?.content ?: "请求成功"
        val data = jsonObject["data"]?.let { convertJsonElement<T>(it) }
        
        return Res(code, message, data)
    }
    
    /**
     * 将JsonElement转换为指定类型
     * 非递归版本，用于入口调用
     */
    inline fun <reified T> convertJsonElement(element: JsonElement): T {
        return convertJsonElementImpl(element, T::class) as T
    }
    
    /**
     * 实际的转换实现，使用非内联函数处理递归
     * 不使用reified，而是接收KClass参数
     */
    @Suppress("UNCHECKED_CAST")
    fun convertJsonElementImpl(element: JsonElement, kClass: kotlin.reflect.KClass<*>): Any? {
        // 根据类型使用不同的转换策略
        return when (kClass) {
            String::class -> element.toString()
            Int::class -> element.jsonPrimitive.int
            Boolean::class -> element.jsonPrimitive.boolean
            Double::class -> element.jsonPrimitive.double
            Long::class -> element.jsonPrimitive.double
            List::class -> {
                if (element is JsonArray) {
                    element.map { convertJsonElementImpl(it, Any::class) }
                } else {
                    emptyList<Any>()
                }
            }
            Map::class -> {
                if (element is JsonObject) {
                    element.mapValues { convertJsonElementImpl(it.value, Any::class) }
                } else {
                    emptyMap<String, Any>()
                }
            }
            else -> {
                try {
                    // 尝试使用kotlinx.serialization转换
                    json.decodeFromJsonElement(element)
                } catch (e: Exception) {
                    // 如果是对象类型，尝试手动创建实例
                    if (element is JsonObject) {
                        createInstanceFromJsonObject(element, kClass)
                    } else {
                        throw IllegalArgumentException("无法将 $element 转换为 $kClass")
                    }
                }
            }
        }
    }
    
    /**
     * 从JsonObject尝试创建实例
     * 这是备用方法，不保证所有KSP生成的类都能正确创建
     */
    fun createInstanceFromJsonObject(jsonObject: JsonObject, kClass: kotlin.reflect.KClass<*>): Any? {
        // 检查是否是KSP生成的类
        val className = kClass.simpleName ?: ""
        
        if (className.endsWith("Impl") || className.contains("Generated")) {
            // 这里我们尝试处理常见的KSP生成的实体格式
            
            // 1. 尝试查找该类的构造函数
            try {
                // 获取所有属性
                val properties = mutableMapOf<String, Any?>()
                
                // 从JSON对象中提取所有属性
                jsonObject.forEach { (key, value) ->
                    properties[key] = when (value) {
                        is JsonPrimitive -> when {
                            value.isString -> value.content
                            value.booleanOrNull != null -> value.boolean
                            value.intOrNull != null -> value.int
                            value.longOrNull != null -> value.long
                            value.doubleOrNull != null -> value.double
                            else -> value.toString()
                        }
                        is JsonArray -> value.map { 
                            if (it is JsonObject) 
                                convertJsonElementImpl(it, Map::class) 
                            else 
                                convertJsonElementImpl(it, Any::class) 
                        }
                        is JsonObject -> convertJsonElementImpl(value, Map::class)
                        else -> null
                    }
                }
                
                // 使用反射尝试创建实例
                // 注意：在KMP中直接使用反射可能会有平台兼容性问题
                // 这里仅作为示例，实际项目中可能需要更复杂的实现
                
                // 简单返回属性Map，作为临时替代方案
                return properties
            } catch (e: Exception) {
                println("反射创建实例失败: ${e.message}")
                // 降级为Map
                return jsonObject.toMap()
            }
        } else {
            // 非KSP生成的类，尝试使用序列化
            throw UnsupportedOperationException("无法处理非KSP生成的类: $kClass")
        }
    }
    
    /**
     * 将JsonObject转换为Map
     */
    private fun JsonObject.toMap(): Map<String, Any?> {
        val result = mutableMapOf<String, Any?>()
        this.forEach { (key, value) ->
            result[key] = when (value) {
                is JsonPrimitive -> when {
                    value.isString -> value.content
                    value.booleanOrNull != null -> value.boolean
                    value.intOrNull != null -> value.int
                    value.longOrNull != null -> value.long
                    value.doubleOrNull != null -> value.double
                    else -> value.toString()
                }
                is JsonArray -> value.map { if (it is JsonObject) it.toMap() else it }
                is JsonObject -> value.toMap()
                else -> null
            }
        }
        return result
    }
    
    /**
     * 将Map转换为实体对象
     * 当无法直接使用序列化器时，可以先转为Map然后使用此方法转回实体
     */
    internal inline fun <reified T> mapToEntity(map: Map<String, Any?>): T {
        // 如果目标类型就是Map，直接返回
        if (T::class == Map::class) {
            return map as T
        }
        
        // 将Map转换为JSON对象
        val jsonObject = map.toJsonObject()
        
        // 使用JSON转换为实体
        return try {
            json.decodeFromJsonElement<T>(jsonObject)
        } catch (e: Exception) {
            // 如果直接转换失败，尝试使用通用转换
            convertJsonElement(jsonObject)
        }
    }
    
    /**
     * 将Map转换为JsonObject
     */
    private fun Map<String, Any?>.toJsonObject(): JsonObject {
        return buildJsonObject {
            this@toJsonObject.forEach { (key, value) ->
                when (value) {
                    null -> put(key, JsonNull)
                    is String -> put(key, JsonPrimitive(value))
                    is Number -> put(key, JsonPrimitive(value))
                    is Boolean -> put(key, JsonPrimitive(value))
                    is Map<*, *> -> @Suppress("UNCHECKED_CAST") {
                        put(key, (value as Map<String, Any?>).toJsonObject())
                    }
                    is List<*> -> put(key, value.toJsonArray())
                    is Array<*> -> put(key, value.toList().toJsonArray())
                    else -> put(key, JsonPrimitive(value.toString()))
                }
            }
        }
    }
    
    /**
     * 将List转换为JsonArray
     */
    private fun List<*>.toJsonArray(): JsonArray {
        return buildJsonArray {
            this@toJsonArray.forEach { value ->
                when (value) {
                    null -> add(JsonNull)
                    is String -> add(JsonPrimitive(value))
                    is Number -> add(JsonPrimitive(value))
                    is Boolean -> add(JsonPrimitive(value))
                    is Map<*, *> -> @Suppress("UNCHECKED_CAST") {
                        add((value as Map<String, Any?>).toJsonObject())
                    }
                    is List<*> -> add(value.toJsonArray())
                    is Array<*> -> add(value.toList().toJsonArray())
                    else -> add(JsonPrimitive(value.toString()))
                }
            }
        }
    }
} 