package com.addzero.kmp.core.network

import com.addzero.kmp.entity.Res
import kotlinx.serialization.KSerializer
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.descriptors.buildClassSerialDescriptor
import kotlinx.serialization.descriptors.element
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.*
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.contextual

/**
 * 创建包含Res序列化器的SerializersModule
 */
fun createResSerializersModule(): SerializersModule {
    return SerializersModule {
        // 注册Res序列化器作为上下文序列化器
        contextual(ResSerializer(JsonElement.serializer()))
        
        // 添加对List的支持
        contextual(ResListSerializer(JsonElement.serializer()))

        // 支持动态类型，处理KSP生成的实体
        polymorphicDefaultDeserializer(Any::class) { JsonElement.serializer() }
    }
}

/**
 * Res泛型类的序列化器
 */
class ResSerializer<T>(private val dataSerializer: KSerializer<T>) : KSerializer<Res<T>> {
    override val descriptor: SerialDescriptor = buildClassSerialDescriptor("com.addzero.kmp.entity.Res") {
        element<Int>("code")
        element<String>("message")
        element("data", dataSerializer.descriptor, isOptional = true)
    }

    override fun deserialize(decoder: Decoder): Res<T> {
        val input = decoder as? JsonDecoder ?: error("只支持JSON格式")
        val jsonObj = input.decodeJsonElement().jsonObject
        
        val code = jsonObj["code"]?.jsonPrimitive?.int ?: 200
        val message = jsonObj["message"]?.jsonPrimitive?.content ?: "请求成功"
        val data = jsonObj["data"]?.let { input.json.decodeFromJsonElement(dataSerializer, it) }
        
        return Res(code, message, data)
    }
    
    override fun serialize(encoder: Encoder, value: Res<T>) {
        val output = encoder as? JsonEncoder ?: error("只支持JSON格式")
        val jsonObj = buildJsonObject {
            put("code", JsonPrimitive(value.code))
            put("message", JsonPrimitive(value.message))
            value.data?.let { put("data", output.json.encodeToJsonElement(dataSerializer, it)) }
        }
        output.encodeJsonElement(jsonObj)
    }
}

/**
 * 专门用于处理List<T>响应的序列化器
 */
class ResListSerializer<T>(elementSerializer: KSerializer<T>) : KSerializer<Res<List<T>>> {
    private val listSerializer = ListSerializer(elementSerializer)
    
    override val descriptor: SerialDescriptor = buildClassSerialDescriptor("com.addzero.kmp.entity.Res.List") {
        element<Int>("code")
        element<String>("message") 
        element("data", listSerializer.descriptor, isOptional = true)
    }
    
    override fun deserialize(decoder: Decoder): Res<List<T>> {
        val input = decoder as? JsonDecoder ?: error("只支持JSON格式")
        val jsonObj = input.decodeJsonElement().jsonObject
        
        val code = jsonObj["code"]?.jsonPrimitive?.int ?: 200
        val message = jsonObj["message"]?.jsonPrimitive?.content ?: "请求成功"
        val data = jsonObj["data"]?.let { input.json.decodeFromJsonElement(listSerializer, it) }
        
        return Res(code, message, data)
    }
    
    override fun serialize(encoder: Encoder, value: Res<List<T>>) {
        val output = encoder as? JsonEncoder ?: error("只支持JSON格式")
        val jsonObj = buildJsonObject {
            put("code", JsonPrimitive(value.code))
            put("message", JsonPrimitive(value.message))
            value.data?.let { put("data", output.json.encodeToJsonElement(listSerializer, it)) }
        }
        output.encodeJsonElement(jsonObj)
    }
}